## Gemini_API.py

import google.generativeai as genai

# Configure Gemini API key
genai.configure(api_key="AIzaSyCRiXUAVZsMd8SuAW1USv4LqnoCVFx0YVQ")

# Create model
model = genai.GenerativeModel('gemini-1.5-flash')

# Function to ask Gemini
def ask_gemini(prompt):
    response = model.generate_content(prompt)
    return response.text





#official google

#from google import genai

#client = genai.Client(api_key="AIzaSyD1hzr6iHOz03Y7iELjqJUhE1mRlXDUSkc")

#response = client.models.generate_content(
    #model="gemini-2.0-flash",
    #contents="Explain how AI works in a few words",
#)

#print(response.text)