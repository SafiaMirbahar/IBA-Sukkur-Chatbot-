import json
import tkinter as tk
from tkinter import scrolledtext
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from PIL import Image, ImageTk
import os
from Gemini_API import ask_gemini

# Load FAQ data
with open("faq_data.json", "r") as file:
    faq_data = json.load(file)

questions = list(faq_data.keys())
answers = list(faq_data.values())

vectorizer = TfidfVectorizer()
tfidf = vectorizer.fit_transform(questions)

def ask_bot(user_input):
    user_tfidf = vectorizer.transform([user_input])
    similarities = cosine_similarity(user_tfidf, tfidf)
    best_match = similarities.argmax()
    score = similarities[0][best_match]
    return answers[best_match] if score > 0.7 else ask_gemini(user_input)

def send_message(event=None):
    user_message = entry.get()
    if user_message.strip() == "":
        return
    chat_area.config(state=tk.NORMAL)
    chat_area.insert(tk.END, "You: " + user_message + "\n", "user")
    bot_response = ask_bot(user_message)
    chat_area.insert(tk.END, "Bot: " + bot_response + "\n\n", "bot")
    chat_area.config(state=tk.DISABLED)
    entry.delete(0, tk.END)

def quick_question(question):
    entry.delete(0, tk.END)
    entry.insert(0, question)
    send_message()

# GUI Setup
window = tk.Tk()
window.title("IBA Chatbot")
window.geometry("320x450")
window.configure(bg="#f5f7fa")
window.resizable(False, False)

# Logo
if os.path.exists("iba_logo.jpeg"):
    img = Image.open("iba_logo.jpeg").resize((50, 50))
    logo = ImageTk.PhotoImage(img)
    logo_label = tk.Label(window, image=logo, bg="#f5f7fa")
    logo_label.pack(pady=2)

# Title
title_label = tk.Label(window, text="IBA Sukkur Chatbot", bg="#f5f7fa", fg="#2c3e50",
                       font=("Segoe UI", 12, "bold"))
title_label.pack(pady=2)

# Chat Area
chat_area = scrolledtext.ScrolledText(window, wrap=tk.WORD, width=38, height=12,
                                      font=("Segoe UI", 9), bg="#ffffff", bd=0)
chat_area.pack(padx=5, pady=5)
chat_area.tag_configure("user", foreground="#1a5276")
chat_area.tag_configure("bot", foreground="#7b241c")
chat_area.config(state=tk.DISABLED)
chat_area.config(state=tk.NORMAL)
chat_area.insert(tk.END, "Bot: Hello! I'm your IBA assistant.\n", "bot")
chat_area.insert(tk.END, "Bot: How can I help you?\n\n", "bot")
chat_area.config(state=tk.DISABLED)

# Entry Field
entry_frame = tk.Frame(window, bg="#f5f7fa")
entry_frame.pack(pady=2)

entry = tk.Entry(entry_frame, width=22, font=("Segoe UI", 10), bd=1, relief=tk.FLAT)
entry.grid(row=0, column=0, padx=3)
entry.bind("<Return>", send_message)

send_button = tk.Button(entry_frame, text="Send", command=send_message, font=("Segoe UI", 9, "bold"),
                        bg="#154360", fg="white", width=7, relief=tk.FLAT)
send_button.grid(row=0, column=1)

# Quick Question Buttons (Updated: Removed Open Days button, Centered Contact button)
button_frame = tk.Frame(window, bg="#f5f7fa")
button_frame.pack(pady=5)

btn_style = {"font": ("Segoe UI", 8), "bg": "#7b241c", "fg": "white", "relief": tk.FLAT, "width": 13}

tk.Button(button_frame, text="🎓 Courses", command=lambda: quick_question("What programs does IBA Sukkur offer?"), **btn_style).grid(row=0, column=0, padx=2, pady=2)
tk.Button(button_frame, text="📝 Apply", command=lambda: quick_question("How can I apply to IBA Sukkur?"), **btn_style).grid(row=0, column=1, padx=2, pady=2)

# Center the Contact button using columnspan
tk.Button(button_frame, text="📞 Contact", command=lambda: quick_question("What is the contact number of IBA Sukkur?"), **btn_style).grid(row=1, column=0, columnspan=2, pady=2)

window.mainloop()
